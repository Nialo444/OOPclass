# java_eclipse_fitness_center
Java program written in procedural style for students to refactor using OOP techniques

This is one of the options for the final exam Part A.

The resulting "refactored" program must demonstrate good object-oriented techniques and demonstrate the four pillars of OOP: encapsulation, inheritance, polymorphism, and abstraction.

Your final refactor codebase must be hosted via GitHub; you will submit for grading only the link to your repository.