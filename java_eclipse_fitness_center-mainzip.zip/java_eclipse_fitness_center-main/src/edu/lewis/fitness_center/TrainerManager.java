package edu.lewis.fitness_center;

import java.util.ArrayList;
import java.util.List;

public class TrainerManager 
{
    private List<Trainer> trainers;
    private int nextId;
    
    public TrainerManager() 
    {
        this.trainers = new ArrayList<>();
        this.nextId = 1;
    }

    public Trainer createTrainer(String name, String specialty) 
    {
        Trainer trainer = new Trainer(nextId, name, specialty);
        nextId++;
        trainers.add(trainer);
        return trainer;
    }

    public Trainer findById(int id) 
    {
        for (Trainer trainer : trainers) 
        {
            if (trainer.getId() == id)
            {
                return trainer;
            }
        }
        return null;
    }

    public List<Trainer> getAll() 
    {
        return new ArrayList<>(trainers);
    }

    public int getCount()
    {
        return trainers.size();
    }

    public boolean updateSchedule(int trainerId, List<String> newSchedule) 
    {
        Trainer trainer = findById(trainerId);
        if (trainer != null) 
        {
            trainer.setSchedule(newSchedule);
            return true;
        }
        return false;
    }

    public boolean addScheduleSlots(int trainerId, List<String> timeSlots) 
    {
        Trainer trainer = findById(trainerId);
        if (trainer != null) 
        {
            for (String slot : timeSlots) 
            {
                trainer.addScheduleSlot(slot);
            }
            return true;
        }
        return false;
    }

}
