package edu.lewis.fitness_center;

import edu.lewis.fitness_center.FitnessClass.Difficulty;
import java.util.Scanner;

public class Main 
{
    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        FitnessCenter center = new FitnessCenter();
        mainMenu(center);
    }

    private static void mainMenu(FitnessCenter center) 
    {
        while (true) {
            System.out.println("\n=== Campus Fitness Center ===");
            System.out.println("1. Add member");
            System.out.println("2. List members");
            System.out.println("3. Add fitness class");
            System.out.println("4. List fitness classes");
            System.out.println("5. Enroll member in class");
            System.out.println("6. Show summary");
            System.out.println("7. Exit");

            int choice = readInt("Choice: ");

            switch (choice) 
            {
                case 1 -> addMember(center);
                case 2 -> center.listMembers();
                case 3 -> addFitnessClass(center);
                case 4 -> center.listFitnessClasses();
                case 5 -> enrollMember(center);
                case 6 -> showSummary(center);
                case 7 -> 
                {
                    System.out.println("Goodbye!");
                    return;
                }
                default -> System.out.println("Invalid choice.");
            }
        }
    }

    private static void addMember(FitnessCenter center) 
    {
        System.out.print("Name: ");
        String name = scanner.nextLine();

        System.out.print("Membership type (student/faculty/community): ");
        String type = scanner.nextLine();

        center.addMember(name, type);
        System.out.println("Member added.");
    }

    private static void addFitnessClass(FitnessCenter center) 
    {
        System.out.print("Class name: ");
        String name = scanner.nextLine();

        System.out.print("Difficulty (beginner/intermediate/advanced): ");
        Difficulty difficulty = Difficulty.fromString(scanner.nextLine());

        int capacity = readInt("Capacity: ");

        center.addFitnessClass(name, difficulty, capacity);
        System.out.println("Class created.");
    }


    private static void enrollMember(FitnessCenter center)
    {
        int memberId = readInt("Member ID: ");
        int classId = readInt("Class ID: ");

        ClassManager.EnrollmentResult result = center.enrollMemberInClass(memberId, classId);

        System.out.println(result.getMessage());
    }

    private static void showSummary(FitnessCenter center) 
    {
        System.out.println("\n=== Summary ===");
        System.out.println("Total members: " + center.getTotalMembers());
        System.out.println("Active members: " + center.getActiveMembers());
        System.out.printf("Outstanding balance: $%.2f%n", center.getTotalBalance());
    }

    private static int readInt(String prompt) 
    {
        while (true) 
        {
            try 
            {
                System.out.print(prompt);
                return Integer.parseInt(scanner.nextLine());
            } 
            catch (NumberFormatException e) 
            {
                System.out.println("Please enter a valid number.");
            }
        }
    }


}
