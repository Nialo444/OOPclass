package edu.lewis.fitness_center;

import java.util.ArrayList;
import java.util.List;

public class Trainer 
{
    private int id;
    private String name;
    private String specialty;
    private List<String> schedule;


    public Trainer(int id, String name, String specialty) 
    {
        this.id = id;
        this.name = name;
        this.specialty = specialty;
        this.schedule = new ArrayList<>();
    }

    public int getId() 
    {
        return id;
    }
    
    public String getName() 
    {
        return name;
    }
    
    public String getSpecialty() 
    {
        return specialty;
    }

    public List<String> getSchedule() 
    {
        return new ArrayList<>(schedule);
    }

    public void setName(String name) 
    {
        this.name = name;
    }
    
    public void setSpecialty(String specialty) 
    {
        this.specialty = specialty;
    }

    public void addScheduleSlot(String timeSlot) 
    {
        if (timeSlot != null && !timeSlot.trim().isEmpty()) 
        {
            schedule.add(timeSlot);
        }
    }

    public void setSchedule(List<String> newSchedule) 
    {
        this.schedule = new ArrayList<>(newSchedule);
    }

    public void clearSchedule() 
    {
        schedule.clear();
    }

    public boolean hasAvailability() 
    {
        return !schedule.isEmpty();
    }

    public String toString() 
    {
        String scheduleStr = schedule.isEmpty() 
            ? "No availability" 
            : String.join(", ", schedule);
        return String.format("[%d] %s - %s (Schedule: %s)",
        id, name, specialty, scheduleStr);
    }

}
