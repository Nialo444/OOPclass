package edu.lewis.fitness_center;

public class FacultyMember extends Member 
{
    public FacultyMember(int id, String name) 
    {
        super(id, name);  // call parent constructor
    }


    public double getDiscountRate() 
    {
        return 0.75;
    }

    public String getMembershipType() 
    {
        return "Faculty";
    }

}
