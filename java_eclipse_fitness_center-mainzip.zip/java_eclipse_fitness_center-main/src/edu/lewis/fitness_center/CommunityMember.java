package edu.lewis.fitness_center;

public class CommunityMember extends Member
{
    public CommunityMember(int id, String name) 
    {
        super(id, name);  // call parent constructor
    }


    public double getDiscountRate() 
    {
        return 1.0;
    }

    public String getMembershipType() 
    {
        return "Community";
    }
}
