package edu.lewis.fitness_center;

public abstract class Member 
{
    private int id;
    private String name;
    private boolean active;
    private double balance;

    public Member(int id, String name) 
    {
    this.id = id;
    this.name = name;
    this.active = true;
    this.balance = 0.0;
    }

    public abstract double getDiscountRate();
    public abstract String getMembershipType();

    public int getId() 
    {
        return id;
    }

    public String getName() 
    {
        return name;
    }

    public boolean isActive() 
    {
        return active;
    }

    public double getBalance() 
    {
        return balance;
    }

    public void setName(String name) 
    {
        this.name = name;
    }


    public void deactivate() 
        {
        this.active = false;
    }

    public void activate() 
    {
        this.active = true;
    }


    public void addCharge(double amount) 
    {
        if (amount > 0) 
        {
            this.balance += amount;
        }
    }

    public void applyPayment(double amount) 
    {
        if (amount > 0)
        {
            this.balance -= amount;
        }
    }

    public double calculateClassFee(double baseFee)
    {
        return baseFee * getDiscountRate();
    }


    @Override
    public String toString() 
    {
        return String.format("[%d] %s (%s, %s) Balance: $%.2f",
        id, name, getMembershipType(), 
        active ? "Active" : "Inactive", balance);
    }

}
