package edu.lewis.fitness_center;

import java.util.ArrayList;
import java.util.List;

public class FitnessClass
{
   public enum Difficulty 
   {
        BEGINNER, 
        INTERMEDIATE, 
        ADVANCED;

        public static Difficulty fromString(String str) {
            try 
            {
                return Difficulty.valueOf(str.toUpperCase());
            } 
            catch (IllegalArgumentException e) 
            {
                return BEGINNER;
            }
        }
    }

    private int id;
    private String name;
    private Difficulty difficulty;
    private int capacity;
    private List<Member> enrolledMembers;

    public FitnessClass(int id, String name, Difficulty difficulty, int capacity) 
    {
        this.id = id;
        this.name = name;
        this.difficulty = difficulty;
        this.capacity = capacity;
        this.enrolledMembers = new ArrayList<>();
    }

    public int getId() 
    {
        return id;
    }
    
    public String getName()
    {
        return name;
    }
    
    public Difficulty getDifficulty() 
    {
        return difficulty;
    }
    
    public int getCapacity() 
    {
        return capacity;
    }
    
    public int getEnrolledCount() 
    {
        return enrolledMembers.size();
    }


    public List<Member> getEnrolledMembers()
    {
        return new ArrayList<>(enrolledMembers);
    }


    public boolean isFull() 
    {
        return enrolledMembers.size() >= capacity;
    }


    public boolean isEnrolled(Member member) 
    {
        return enrolledMembers.contains(member);
    }

    public int getAvailableSpots() 
    {
        return capacity - enrolledMembers.size();
    }


    public boolean enrollMember(Member member) 
    {
        if (!member.isActive()) 
        {
            return false;
        }
        if (isFull()) 
        {
            return false;
        } 
        if (isEnrolled(member)) 
        {
            return false;
        }
        
        enrolledMembers.add(member);
        return true;
    }


    public boolean removeMember(Member member) 
    {
        return enrolledMembers.remove(member);
    }

    public String toString()
    {
        return String.format("[%d] %s (%s, capacity %d, enrolled %d)",
                id, name, difficulty, capacity, enrolledMembers.size());
    }

}


