package edu.lewis.fitness_center;

import java.util.ArrayList;
import java.util.List;

public class MemberManager 
{
    private List<Member> members;
    private int nextId;

    public MemberManager() 
    {
        this.members = new ArrayList<>();
        this.nextId = 1;
    }

    public Member createMember(String name, String type) 
    {
        Member member;
        type = type.toLowerCase();
        switch (type) 
        {
            case "student":
                member = new StudentMember(nextId, name);
                break;
            case "faculty":
                member = new FacultyMember(nextId, name);
                break;
            case "community":
            default:
                member = new CommunityMember(nextId, name);
                break;
        }
        nextId++;
        members.add(member);
        return member;
    }


    public Member findById(int id) 
    {
        for (Member member : members) 
        {
            if (member.getId() == id) 
            {
                return member;
            }
        }
        return null;
    }

    public List<Member> getAll() 
    {
        return new ArrayList<>(members);
    }

    public int getCount() 
    {
        return members.size();
    }

    public int getActiveCount() 
    {
        int count = 0;
        for (Member member : members) 
        {
            if (member.isActive()) 
            {
                count++;
            }
        }
        return count;
    }

    public double getTotalBalance() 
    {
        double total = 0.0;
        for (Member member : members) 
        {
            total += member.getBalance();
        }
        return total;
    }

    public boolean deactivateMember(int memberId) 
    {
        Member member = findById(memberId);
        if (member != null && member.isActive()) 
        {
            member.deactivate();
            return true;
        }
        return false;
    }

    public boolean addCharge(int memberId, double amount) 
    {
        Member member = findById(memberId);
        if (member != null) 
        {
            member.addCharge(amount);
            return true;
        }
        return false;
    }

    public boolean applyPayment(int memberId, double amount) 
    {
        Member member = findById(memberId);
        if (member != null) 
        {
            member.applyPayment(amount);
            return true;
        }
        return false;
    }

}
