package edu.lewis.fitness_center;

import edu.lewis.fitness_center.FitnessClass.Difficulty;

public class FitnessCenter 
{

    private final MemberManager memberManager;
    private final TrainerManager trainerManager;
    private final ClassManager classManager;

    public FitnessCenter() 
    {
        this.memberManager = new MemberManager();
        this.trainerManager = new TrainerManager();
        this.classManager = new ClassManager();
    }

    public Member addMember(String name, String type) 
    {
        return memberManager.createMember(name, type);
    }

    public boolean deactivateMember(int memberId) 
    {
        return memberManager.deactivateMember(memberId);
    }

    public boolean addCharge(int memberId, double amount) 
    {
        return memberManager.addCharge(memberId, amount);
    }

    public boolean applyPayment(int memberId, double amount) 
    {
        return memberManager.applyPayment(memberId, amount);
    }

    public void listMembers() 
    {
        for (Member m : memberManager.getAll()) 
        {
            System.out.println(m);
        }
    }
    
    public int getTotalMembers() 
    {
        return memberManager.getCount();
    }

    public int getActiveMembers() 
    {
        return memberManager.getActiveCount();
    }

    public double getTotalBalance() 
    {
        return memberManager.getTotalBalance();
    }



    public Trainer addTrainer(String name, String specialty) 
    {
        return trainerManager.createTrainer(name, specialty);
    }

    public void listTrainers() 
    {
        for (Trainer t : trainerManager.getAll()) 
        {
            System.out.println(t);
        }
    }


    
    public FitnessClass addFitnessClass(String name, Difficulty difficulty, int capacity) 
    {
        return classManager.createClass(name, difficulty, capacity);
    }

    public void listFitnessClasses() 
    {
        for (FitnessClass fc : classManager.getAll()) 
        {
            System.out.println(fc);
        }
    }


    public ClassManager.EnrollmentResult enrollMemberInClass(int memberId, int classId) 
    {
        Member member = memberManager.findById(memberId);
        if (member == null) 
        {
            return new ClassManager.EnrollmentResult(false, "Member not found", 0.0);
        }

        return classManager.enrollMember(classId, member);
    }




}
