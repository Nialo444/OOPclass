package edu.lewis.fitness_center;

public class StudentMember extends Member 
{
    public StudentMember(int id, String name) 
    {
        super(id, name);  // call parent constructor
    }

    public double getDiscountRate() 
    {
        return 0.5;
    }

    public String getMembershipType() 
    {
        return "Student";
    }

}
