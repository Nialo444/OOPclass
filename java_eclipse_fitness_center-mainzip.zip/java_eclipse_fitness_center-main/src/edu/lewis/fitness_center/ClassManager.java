package edu.lewis.fitness_center;

import edu.lewis.fitness_center.FitnessClass.Difficulty;
import java.util.ArrayList;
import java.util.List;

public class ClassManager 
{
    private List<FitnessClass> classes;
    private int nextId;
    private static final double BASE_CLASS_FEE = 10.0;

    public ClassManager() 
    {
        this.classes = new ArrayList<>();
        this.nextId = 1;
    }


    public FitnessClass createClass(String name, Difficulty difficulty, int capacity) 
    {
        FitnessClass fitnessClass = new FitnessClass(nextId, name, difficulty, capacity);
        nextId++;
        classes.add(fitnessClass);
        return fitnessClass;
    }

    public FitnessClass findById(int id) 
    {
        for (FitnessClass fc : classes) 
        {
            if (fc.getId() == id) 
            {
                return fc;
            }
        }
        return null;
    }

    public List<FitnessClass> getAll() 
    {
        return new ArrayList<>(classes);
    }

    public int getCount() 
    {
        return classes.size();
    }

    public EnrollmentResult enrollMember(int classId, Member member) 
    {
        FitnessClass fitnessClass = findById(classId);
        
        if (fitnessClass == null) 
        {
            return new EnrollmentResult(false, "Class not found", 0.0);
        }
        
        if (!member.isActive()) 
        {
            return new EnrollmentResult(false, "Cannot enroll inactive member", 0.0);
        }
        
        if (fitnessClass.isFull()) 
        {
            return new EnrollmentResult(false, "Class is full", 0.0);
        }
        
        if (fitnessClass.isEnrolled(member)) 
        {
            return new EnrollmentResult(false, "Member already enrolled", 0.0);
        }

        boolean enrolled = fitnessClass.enrollMember(member);
        
        if (!enrolled) 
        {
            return new EnrollmentResult(false, "Enrollment failed", 0.0);
        }

        double fee = member.calculateClassFee(BASE_CLASS_FEE);
        member.addCharge(fee);

        String message = String.format(
            "Enrolled %s in %s. Charged $%.2f (base $%.2f, type: %s)",
            member.getName(), fitnessClass.getName(), 
            fee, BASE_CLASS_FEE, member.getMembershipType()
        );

        return new EnrollmentResult(true, message, fee);
    }


    public static class EnrollmentResult 
    {
        private boolean success;
        private String message;
        private double feeCharged;

        public EnrollmentResult(boolean success, String message, double feeCharged) 
        {
            this.success = success;
            this.message = message;
            this.feeCharged = feeCharged;
        }

        public boolean isSuccess() 
        {
            return success;
        }
        
        public String getMessage() 
        {
            return message;
        }
        
        public double getFeeCharged() 
        {
            return feeCharged;
        }
    }

}
