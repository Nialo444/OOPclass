package edu.university.cafe.model;

public class LineItem {

}
