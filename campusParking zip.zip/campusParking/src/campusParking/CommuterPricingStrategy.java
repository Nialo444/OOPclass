package campusParking;

import java.math.BigDecimal;

public class CommuterPricingStrategy implements PricingStrategy
{
	public BigDecimal computeMonthly(PermitSelection selection) 
	{
        BigDecimal base = BigDecimal.valueOf(35.00); //automatic 15% discount
        
        return base.multiply(BigDecimal.valueOf(0.85));
    }

}
