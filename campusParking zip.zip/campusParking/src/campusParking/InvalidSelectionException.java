package campusParking;

public class InvalidSelectionException extends RuntimeException
{
	public InvalidSelectionException(String message)
	{
		super(message);
	}
}
