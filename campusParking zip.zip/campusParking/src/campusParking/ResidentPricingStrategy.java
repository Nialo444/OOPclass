package campusParking;

import java.math.BigDecimal;

public class ResidentPricingStrategy implements PricingStrategy
{
	//@override
	public BigDecimal computeMonthly(PermitSelection selection) 
	{
        return BigDecimal.valueOf(45.00); //base rate
    }

}
