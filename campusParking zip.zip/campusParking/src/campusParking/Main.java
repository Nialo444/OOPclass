package campusParking;

import java.util.Scanner;

public class Main 
{
	public static void main(String[] args)
	{
		Scanner scan = new Scanner(System.in);
		
		while (true) 
		{
			try 
            {
                System.out.print("Enter permit type (RESIDENT/COMMUTER): ");
                PermitType permit = PermitType.valueOf(scan.next().toUpperCase());

                System.out.print("Enter vehicle type (CAR/SUV/MOTORCYCLE): ");
                VehicleType vehicle = VehicleType.valueOf(scan.next().toUpperCase());

                System.out.print("Carpool? (Y/N): ");
                boolean carpool = scan.next().equalsIgnoreCase("Y");

                System.out.print("Months (1-12): ");
                int months = scan.nextInt();

                PermitSelection selection = new PermitSelection(permit, vehicle, carpool, months);

                PricingStrategy strategy = (permit == PermitType.RESIDENT)
                        ? new ResidentPricingStrategy()
                        : new CommuterPricingStrategy();

                PricingPipeline pipeline = new PricingPipeline();
                pipeline.addModifier(vehicle);
                if (carpool) pipeline.addModifier(new CarpoolDiscount());

                PricingCalculator calc = new PricingCalculator(strategy, pipeline);
                PricingCalculator.Result result = calc.calculate(selection);

                Receipt.printReceipt(selection, result);
                break;

            } 
			catch (InvalidSelectionException e) 
			{
                System.out.println("Error: " + e.getMessage());
            } 
			catch (Exception e) 
			{
                System.out.println("Invalid input try again.");
                scan.nextLine();
            }
        }

		
		
	}
}
