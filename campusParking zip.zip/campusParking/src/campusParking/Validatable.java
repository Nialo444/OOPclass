package campusParking;

public interface Validatable 
{
	void validate();
}
