package campusParking;

import java.math.BigDecimal;

public enum VehicleType implements RateModifier
{
	CAR
	{
		//@override
		public BigDecimal apply(BigDecimal rate)
		{
			return rate;
		}
	},
	SUV
	{
		//@override
		public BigDecimal apply(BigDecimal rate) 
		{
            return rate.multiply(BigDecimal.valueOf(1.15)); //+15%
        }
	},
	MOTORCYCLE
	{
		//@override
		public BigDecimal apply(BigDecimal rate) 
		{
            return rate.multiply(BigDecimal.valueOf(0.70)); //-30%
        }

	};
	
	public abstract BigDecimal apply(BigDecimal rate); 

}
