package campusParking;

import java.math.RoundingMode;

public class Receipt 
{
	public static void printReceipt(PermitSelection selection, PricingCalculator.Result result)
	{
		System.out.println("\n--- Parking Permit Receipt ---");
		System.out.println("Permit Type: " + selection.getPermitType());
		System.out.println("Vehicle Type: " + selection.getVehicleType());
		System.out.println("Carpool: " + (selection.isCarpool() ? "Yes" : "No"));
        System.out.println("Months: " + selection.getMonths());
        System.out.println("Monthly Rate: $" + result.modifiedMonthly.setScale(2, RoundingMode.HALF_UP));
        System.out.println("Subtotal: $" + result.subtotal);
        System.out.println("Campus Fee (5%): $" + result.campusFee);
        System.out.println("Total: $" + result.total);
	}
}
