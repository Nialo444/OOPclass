package campusParking;

public enum PermitType 
{
	RESIDENT,
    COMMUTER
}
