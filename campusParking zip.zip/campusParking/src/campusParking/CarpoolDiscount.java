package campusParking;

import java.math.BigDecimal;

public class CarpoolDiscount implements RateModifier
{
	public BigDecimal apply(BigDecimal rate) 
	{
        return rate.multiply(BigDecimal.valueOf(0.90)); //-10% car pool discount
    }
}
