package campusParking;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class PricingPipeline 
{
	private List<RateModifier> modifiers = new ArrayList<>();
	
	
	public void addModifier(RateModifier modifier) 
	{
        modifiers.add(modifier);
	}
	
	public BigDecimal applyAll(BigDecimal rate) 
	{
        BigDecimal current = rate;
        for (RateModifier mod : modifiers) 
        {
            current = mod.apply(current);
        }
        return current;
    }

}
