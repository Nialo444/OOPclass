package campusParking;

import java.math.BigDecimal;
import java.math.RoundingMode;

public class PricingCalculator 
{
	private PricingStrategy strategy;
    private PricingPipeline pipeline;

	public PricingCalculator(PricingStrategy strategy, PricingPipeline pipeline) 
	{
        this.strategy = strategy;
        this.pipeline = pipeline;
    }

	public Result calculate(PermitSelection selection) 
	{
        BigDecimal baseMonthly = strategy.computeMonthly(selection);
        BigDecimal modifiedMonthly = pipeline.applyAll(baseMonthly);
        BigDecimal subtotal = modifiedMonthly.multiply(BigDecimal.valueOf(selection.getMonths()));
        BigDecimal campusFee = subtotal.multiply(BigDecimal.valueOf(0.05));
        BigDecimal total = subtotal.add(campusFee).setScale(2, RoundingMode.HALF_UP);

        return new Result(baseMonthly, modifiedMonthly, subtotal, campusFee, total);
    }

	public static class Result 
	{
        public final BigDecimal baseMonthly, modifiedMonthly, subtotal, campusFee, total;
        
        public Result(BigDecimal baseMonthly, BigDecimal modifiedMonthly, BigDecimal subtotal, BigDecimal campusFee, BigDecimal total) 
        {
            this.baseMonthly = baseMonthly;
            this.modifiedMonthly = modifiedMonthly;
            this.subtotal = subtotal;
            this.campusFee = campusFee;
            this.total = total;
        }
    }
}
