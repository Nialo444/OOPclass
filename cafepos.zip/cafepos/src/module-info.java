/**
 * 
 */
/**
 * 
 */
module cafepos {
}