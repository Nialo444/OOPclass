package cafepos.model;

import java.math.BigDecimal;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.List;

public class Order 
{
	private List<LineItem> lineItems = new ArrayList<>();
	private BigDecimal taxRate = new BigDecimal("0.07");
	
	public void addItem(Product item, int quantity)
	{
		LineItem lineItem = new LineItem(item, quantity);
		lineItems.add(lineItem);
	}
	
	public BigDecimal subtotal()
	{
		BigDecimal sum = BigDecimal.ZERO;
		for (LineItem li : lineItems)
		{
			sum = sum.add(li.lineTotal());
		}
		return sum;
	}
	
	//taxes
	public BigDecimal tax() 
	{
        return subtotal().multiply(taxRate);
    }
	
	public BigDecimal total() 
	{
        return subtotal().add(tax());
    }
	
	//gets a copy of the line items
	public List<LineItem> getLineItems()
	{
		return new ArrayList<>(lineItems);
	}
	
	public String toString()
	{
		StringBuilder receipt = new StringBuilder("receipt:\n");
		for(LineItem li: lineItems)
		{
			receipt.append(li.toString()).append("\n");
		}
		receipt.append("subtotal: $").append(subtotal()).append("\n");
		receipt.append("tax: $").append(tax()).append("\n"); 
		receipt.append("total: $").append(total()).append("\n");
		return receipt.toString();
	}
	
}
