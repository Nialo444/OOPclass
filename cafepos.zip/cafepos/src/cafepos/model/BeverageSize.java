package cafepos.model;

import java.math.BigDecimal;
import java.util.Scanner;

public enum BeverageSize
{
	small(0.8),
	medium(1.0),
	large(1.2);
	
	private double multiplier;
	
	BeverageSize(double multiplier)
	{
		this.multiplier = multiplier;
	}
	
	public double getMultiplier()
	{
		return multiplier;
	}
}
