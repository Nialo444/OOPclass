package cafepos.model;

import java.math.BigDecimal; 
import java.util.Scanner;

public abstract class Product 
{
	private String id;
	private String name;
	private BigDecimal basePrice;
	
	//constructor
	public Product(String id, String name, BigDecimal basePrice)
	{
		setId(id);
		setName(name);
		setBasePrice(basePrice);
	}
	
	//getters
	public String getId() 
	{
        return id;
    }

    public String getName() 
    {
        return name;
    }

    public BigDecimal getBasePrice() 
    {
        return basePrice;
    }

    //setters that check for bad data too
    public void setId(String id)
    {
    	if(id == null || id.isBlank())
    	{
    		throw new IllegalArgumentException("product ID cannot be blank");
    	}
    	this.id = id;
    }
    public void setName(String name)
    {
    	if(name == null || name.isBlank())
    	{
    		throw new IllegalArgumentException("product name cannot be blank");
    	}
    	this.name = name;
    }
    public void setBasePrice(BigDecimal basePrice)
    {
    	if (basePrice == null || basePrice.compareTo(BigDecimal.ZERO) < 0) 
    	{
            throw new IllegalArgumentException("Base price must be non-negative.");
        }
        this.basePrice = basePrice;
    }
    
    //menu display
    public String getDisplayName() 
    {
        return String.format("%s - %s ($%s)", id, name, basePrice);
    }

    public abstract BigDecimal price();
	
}
