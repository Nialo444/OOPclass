package cafepos.model;

import java.math.BigDecimal;
import java.util.Scanner;

public class LineItem 
{
	
	private Product item;
	private int quantity;
	
	public LineItem(Product item, int quantity)
	{
		if (item == null) 
		{
			throw new IllegalArgumentException("product cannot be null");
		}
		if (quantity <= 0) 
		{
			throw new IllegalArgumentException("quantity must be greater than 0");
		}
		this.item = item;
	    this.quantity = quantity;
	}
	
	public Product getItem()
	{
		return item;
	}
	
	public void setItem(Product item)
	{
		if(item == null)
		{
			throw new IllegalArgumentException("product cannot be null");
		}
		this.item = item;
	}
	
	public int getQuantity() 
	{
	    return quantity;
	}
	
	
	public void setItem(int quantity)
	{
		if(quantity <= 0)
		{
			throw new IllegalArgumentException("quantity must be greater than 0");
		}
		this.quantity = quantity;
	}
	
	public BigDecimal lineTotal()
	{
		return item.price().multiply(BigDecimal.valueOf(quantity));
	}
	
	public String toString() 
	{
		return quantity + " x " + item.getDisplayName() + " = $" + lineTotal();
	}
}


