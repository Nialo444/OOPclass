package cafepos.model;

import java.math.BigDecimal;
import java.util.Scanner;

public class Beverage extends Product
{
	private BeverageSize size;
	
	
	public Beverage(String id, String name, BigDecimal basePrice, BeverageSize size)
	{
		super(id, name, basePrice);
		setSize(size);
	}
	
	public BeverageSize getSize()
	{
		return size;
	}
	
	public void setSize(BeverageSize size)
	{
		if (size == null)
		{
	        throw new IllegalArgumentException("Size cannot be null");
	    }
	    this.size = size;
	}
	
	//beautiful line calculating price
	//@Override
	public BigDecimal price()
	{
		return getBasePrice().multiply(BigDecimal.valueOf(size.getMultiplier()));
	}
	
	//display name for menu
	//@Override
	public String getDisplayMenu()
	{
		return super.getDisplayName() + " (" + size + ")";
	}
	
}
