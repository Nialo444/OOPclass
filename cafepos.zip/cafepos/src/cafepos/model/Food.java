package cafepos.model;

import java.math.BigDecimal;
import java.util.Scanner;

public class Food extends Product
{
	private boolean extraCheese;
	private boolean glutenFree;
	
	public Food(String id, String name, BigDecimal basePrice, boolean extraCheese, boolean glutenFree)
	{
		super(id, name, basePrice);
		this.extraCheese = extraCheese;
	    this.glutenFree = glutenFree;
	}
	
	public boolean hasExtraCheese()
	{
		return extraCheese;
	}
	
	public void setExtraCheese (boolean extraCheese)
	{
		this.extraCheese = extraCheese;
	}
	
	public boolean hasGlutenFree()
	{
		return glutenFree;
	}
	
	public void setGlutenFree (boolean glutenFree)
	{
		this.glutenFree = glutenFree;
	}
	
	
	//extra charges for changes
	//@Override
	public BigDecimal price()
	{
		BigDecimal total = getBasePrice();
		if(extraCheese)
		{
			total = total.add(new BigDecimal("1.00"));
		}
		if(glutenFree)
		{
			total = total.add(new BigDecimal("1.00"));
		}
		return total;
	}
	
	//changes the display to match what they added
	//@override 
	public String getDisplayName()
	{
		String display = super.getDisplayName();
		if(extraCheese)
		{
			display += " + extra cheese";
		}
		if(glutenFree)
		{
			display += " + gluten free";
		}
		return display;
	}

}
