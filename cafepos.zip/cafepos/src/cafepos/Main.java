package cafepos;

import cafepos.data.Menu;
import cafepos.model.*;
import java.math.BigDecimal;
import java.util.Scanner;


public class Main 
{

	public static void main(String[] args) 
	{
		Scanner scan = new Scanner(System.in);
		Menu menu = new Menu();
		Order order = new Order();
		
		System.out.println("welcome to the campus cafe.");
		boolean keepRunning = true;
		
		while(keepRunning == true)
		{
			System.out.println("\n--- Menu ---");
			menu.printMenu();
			
			System.out.print("Enter product ID to add to order (or 'done' to finish): ");
			String input = scan.nextLine().trim();
			if(input.equalsIgnoreCase("done"))
			{
				keepRunning = false;
				break;
			}
			
			Product selected = menu.getProductId(input);
			if(selected == null)
			{
				System.out.println("not a product ID. Try again.");
                continue;
			}
			
			System.out.println("enter quanitiy: ");
			int qty;
			try
			{
				qty = Integer.parseInt(scan.nextLine().trim());
				if(qty <= 0)
				{
					System.out.println("quantity has to be more than 0");
					continue;
				}
			}
			catch(NumberFormatException e)
			{
				System.out.println("not a number");
				continue;
			}
			
			if(selected instanceof Food)
			{
				Food chosenFood = (Food) selected;
				
				System.out.println("Extra cheese? (y/n): ");
				String cheese = scan.nextLine().trim();
				chosenFood.setExtraCheese(cheese.equalsIgnoreCase("y"));
				
				System.out.print("Gluten free? (y/n): ");
				String gluten = scan.nextLine().trim();
				chosenFood.setGlutenFree(gluten.equalsIgnoreCase("y"));
				
			}
			if (selected instanceof Beverage) 
			{
                Beverage beverage = (Beverage) selected;
                System.out.print("Choose size (small/medium/large): ");
                String sizeInput = scan.nextLine().trim().toLowerCase();

                try 
                {
                    BeverageSize size = BeverageSize.valueOf(sizeInput);
                    beverage.setSize(size);
                } 
                catch (IllegalArgumentException e) 
                {
                    System.out.println("invalid size. defaulting to medium.");
                    beverage.setSize(BeverageSize.medium);
                }
			}
			order.addItem(selected, qty);
			System.out.println(qty + "x " + selected.getDisplayName() + " added to order");
		}
		System.out.println("\n ---Final Recipt---");
		System.out.println(order);
		System.out.println("thank you");
	}
	
}
