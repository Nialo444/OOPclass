package cafepos.data;

import cafepos.model.*;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

public class Menu 
{
	private List<Product> products = new ArrayList<>();
	
	public Menu()
	{
		//adds drinks 
		products.add(new Beverage("1", "coffee", new BigDecimal("2.00"), BeverageSize.small));
		products.add(new Beverage("2", "tea", new BigDecimal("1.00"), BeverageSize.small));
		
		//adds food
		products.add(new Food("3", "sandwich", new BigDecimal("2.00"), false, false));
		products.add(new Food("4", "baconeggandcheese", new BigDecimal("5.00"), false, false));
	}
	
	
	public List<Product> getProducts()
	{
		return new ArrayList<>(products);
	}
	
	public Product getProductId(String id)
	{
		for(Product p : products)
		{
			if(p.getId().equals(id))
			{
				return p;
			}
		}
		return null;
	}
	
	public void printMenu()
	{
		System.out.println("Menu: ");
		for(Product p: products) 
		{
			System.out.println(p.getId() + ". " + p.getDisplayName() + " - $" + p.price());
		}
	}
}
