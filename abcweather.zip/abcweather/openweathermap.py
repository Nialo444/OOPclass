from abc_api_base import APIBase
from dotenv import load_dotenv
import os

load_dotenv()

BASE_URL = f'https://api.openweathermap.org/data/2.5/weather?appid={os.getenv('OWM_API_KEY')}'

class OpenWeatherMap(APIBase):
    
    def __init__(self, units, city, timeout=10, params=None):
        self.units = units
        params = {'q': city,'units': self.units}
        super().__init__(BASE_URL, params, timeout)
        

    def call_api(self):
        self.data = self.get_api()

    def __str__(self):
        if self.status != 0:
            return self.message
        data = self.data

        return (f'the location is {self.data["name"]}:\n'
                f'Temperature: {self.data['main']["temp"]}°C\n'
                f'Humidity: {self.data['main']['humidity']}%'
                f'Wind Speed: {self.data['wind']['speed']} m/s\n'
                f'sunrise at {data['sys']['sunrise']} and sunset at {data['sys']['sunset']}\n')
