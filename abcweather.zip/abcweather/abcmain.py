from openweathermap import OpenWeatherMap

def main_function():
    while True:
        city = input("Enter city name (or 'exit' to quit): ")
        if city.lower() == 'exit':
            break
        units = input("Enter units (metric/imperial): ")
        
        weather_api = OpenWeatherMap(units, city)
        weather_api.call_api()
        print(weather_api)

if __name__ == "__main__":
    main_function()
